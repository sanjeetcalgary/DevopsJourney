package DevicefarmPOC.DevicefarmPOC;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AMFLaunch {

	WebDriver driver;
	String crm = "https://amerifirst-qa.bluesageusa.com/crm";
	@Before
	public void setUp() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();		
	}
	
	@Test
	public void inetract() throws Exception {
		driver.get(crm);
		Thread.sleep(3000);
		driver.findElement(By.id("userName-inputEl")).sendKeys("skumar");
		driver.findElement(By.id("password-inputEl")).sendKeys("bluesage123");
		driver.findElement(By.id("btnLogin")).click();
		Thread.sleep(5000);
		List<WebElement> links = driver.findElements(By.xpath("//div[contains(@id,'link')]"));
		for(WebElement e: links) {
			System.out.println("Links: "+e.getText());
			e.click();
			Thread.sleep(10000);
		}
	}
	
	@After
	public void tearDown() throws Exception {
		driver.findElement(By.xpath("//a[@data-selenium-id='btnUser']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@data-selenium-id='btnLogout']")).click();
		Thread.sleep(3000);
		driver.close();
		driver.quit();
		
	}
}
